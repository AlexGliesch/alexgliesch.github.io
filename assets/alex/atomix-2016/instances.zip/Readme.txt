The instance input files have the following structure:


On the first line, the instance name is given.
The following line contains an integer with the number of atoms n.
The following line contains two integers, denoting the board width w and the board height h.
The following h lines contain w characters each, and denote the instance board.
Then follow 2 integers mw and mh, representing, respectively, the width and height of the molecule. 
The following mh lines contain mw characters each, denoting the molecule to be assembled.
Then follows a line contains an integer f with the number of final states.
The following f lines contain 2 integers each, denoting the coordinates (row, column) where the final state is located.