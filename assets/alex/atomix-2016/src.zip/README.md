# Running

To run, use script Atomix.py (See --help for options). This script recompiles the code for each instance and parameter set, in order to optimize data structure initialization. 

Don't compile directly from the makefile.