#pragma once
#include "Definitions.h"
#define InstanceName "../atomix_02.in"
#define NumAtoms 5
#define NumFinalStates 6
#define BoardWidth 14
#define BoardHeight 11
#define BoardSize 154
#define MoleWidth 3
#define MoleHeight 3
#define MoleSize 9
#define NumFreePositions 61
const char ParamBoard[] = "###############...###########...###########.#.#.#......##.#.#3#..2#..##.1#..#####..##.......#....##.......#....##.#####.5....##..4########################";
const char ParamMole[] = ".2.135.4.";

// Runtime parameters 

#define ParamInputFile "../atomix_02.in"
#define ParamOutputFile ""
#define ParamTimeLimit 30
#define ParamMemoryLimit 500
#define ParamAlgorithm AlgPEAStar
#define ParamHeuristic HeuAllFinalStates
#define ParamTieBreaking TBGoalCount
#define ParamPDB PDBStatic
#define ParamSilent false
#define ParamPrintOutputPath false
#define ParamPrintInitialHeuristic false
#define ParamNumRandomStaticPDBs 3
#define ParamRandomSeed -1
#define ParamRandomStaticPDB RandomStaticPDBGreedy